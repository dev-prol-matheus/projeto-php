   <nav>
       <ul>
       <div class="dropdown">
          <button onclick="toggleDropdown()" class="dropbtn">Cadastros</button>
          <div id="myDropdown" class="dropdown-content">
            <a href="cadastrarcColaboradores.php">Colaborares</a>
            <a href="cadastrarKits.php">kits</a>
            <a href="cadastrarUsuarios.php">Usuários</a>
          </div>
        </div>
        <li><a href="Listadecolaboradores.php">Colaboradores</a></li>
        <li><a href="solicitacao.php">Solicitação de Kits</a></li>
        <li><a href="emUso.php">Kits em Uso</a></li>
        <li><a href="historicoSolicitacoes.php">Histórico de Uso</a></li>
        <li><a href="php/logout.php">Sair</a></li>

      </ul>
    </nav>