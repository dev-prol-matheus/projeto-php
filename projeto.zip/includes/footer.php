<footer>
    <p> &copy <?php echo date('Y')?> - Turma Programação Web com PHP </p> 
</footer>

<script src="javascript/menu.js"></script>